package com.graphqljava.tutorial.moviedetails;

import com.google.common.collect.ImmutableMap;
import graphql.schema.DataFetcher;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class GraphQLDataFetchers {

    private static List<Map<String, String>> movies = Arrays.asList(
            ImmutableMap.of("id", "movie-1",
                    "name", "The Hobbit: An Unexpected Journey",
                    "genre", "Adventure",
                    "directorId", "director-1"),
            ImmutableMap.of("id", "movie-2",
                    "name", "The Old Guard",
                    "genre", "Action",
                    "directorId", "director-2"),
            ImmutableMap.of("id", "movie-3",
                    "name", "Interstellar",
                    "genre", "Science Fiction",
                    "directorId", "director-3")
    );

    private static List<Map<String, String>> directors = Arrays.asList(
            ImmutableMap.of("id", "director-1",
                    "firstName", "Peter",
                    "lastName", "Jackson"),
            ImmutableMap.of("id", "director-2",
                    "firstName", "Gina",
                    "lastName", "Prince"),
            ImmutableMap.of("id", "director-3",
                    "firstName", "Christopher",
                    "lastName", "Nolan")
    );

    public DataFetcher getMovieByIdDataFetcher() {
        return dataFetchingEnvironment -> {
            String movieId = dataFetchingEnvironment.getArgument("id");
            return movies
                    .stream()
                    .filter(movie -> movie.get("id").equals(movieId))
                    .findFirst()
                    .orElse(null);
        };
    }

    public DataFetcher getDirectorDataFetcher() {
        return dataFetchingEnvironment -> {
            Map<String, String> movie = dataFetchingEnvironment.getSource();
            String directorId = movie.get("directorId");
            return directors
                    .stream()
                    .filter(director -> director.get("id").equals(directorId))
                    .findFirst()
                    .orElse(null);
        };
    }
}
