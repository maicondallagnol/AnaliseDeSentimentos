/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unesp.rc.junit5tutorial;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

/**
 *
 * @author frank
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class VectorTest {

    public VectorTest() {
    }

    /**
     * Test of equal method, of class Vector.
     */
    @Disabled
    @Order(2)
    @Test
    @DisplayName("Testando se o vetores são iguais")
    public void testEqual() {
        System.out.println("equal");
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3};
        boolean expResult = true;
        boolean result = Vector.equal(a, b);
        assertEquals(expResult, result);
    }

    /**
     * Test of size method, of class Vector.
     */
    @Order(1)
    @Test
    @DisplayName("Testando se o vetores são do mesmo tamanho")
    public void testSize() {
        System.out.println("size");
        int[] a = {1, 2, 3};
        int[] b = {1, 2, 3, 4};
        boolean expResult = false;
        boolean result = Vector.size(a.length, b.length);
        assertEquals(expResult, result);
    }

}
