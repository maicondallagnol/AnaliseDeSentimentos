/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.unesp.rc.junit5tutorial;

/**
 *
 * @author frank
 */
public final class Vector {

    private Vector() {
    }

    /**
     * Verifica se os vetores são iguais
     *
     * @param a
     * @param b
     * @return
     */
    public static boolean equal(int[] a, int[] b) {
        if ((a == null) || (b == null)) {
            throw new IllegalArgumentException("null argument");
        }

        if (a.length != b.length) {
            return false;
        }

        for (int i = 0; i < a.length; i++) {
            if (a[i] != b[i]) {
                return false;
            }
        }

        return true;
    }

    public static boolean size(int a, int b) {

        if ((a < 0) || (b < 0)) {
            throw new IllegalArgumentException("Valores negativos não são permitidos!");
        }

        if (a != b) {
            return false;
        } else {
            return true;
        }

    }

}
