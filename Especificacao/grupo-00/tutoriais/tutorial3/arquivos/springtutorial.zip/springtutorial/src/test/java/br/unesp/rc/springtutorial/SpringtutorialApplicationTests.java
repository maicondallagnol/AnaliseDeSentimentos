package br.unesp.rc.springtutorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringtutorialApplicationTests {

	@Test
	void contextLoads() {
	}

}
