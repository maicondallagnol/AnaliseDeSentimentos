package br.unesp.rc.springtutorialmogodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtutorialmogodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtutorialmogodbApplication.class, args);
	}

}
